#!/bin/sh
export OMP_NUM_THREADS=1
pycbc_inference \
--config-files /workspace/chendawww/server/pe/GW170608/Injection/test/lisa_smbhb_relbin.ini \
--output-file /workspace/chendawww/server/pe/GW170608/Injection/test/lisa_smbhb_inj_pe.hdf \
--force \
--nprocesses 1 \
--fft-backends fftw \
--verbose

# PLEASE NOTE: This example is currently forcing a FFTW backend because MKL
#              seems to fail for FFT lengths > 2^24. This is fine for most LIGO
#              applications, but an issue for most LISA applications.

pycbc_inference_plot_posterior \
    --input-file /workspace/chendawww/server/pe/GW170608/Injection/test/lisa_smbhb_inj_pe.hdf \
    --output-file /workspace/chendawww/server/pe/GW170608/Injection/test/lisa_smbhb_mass_tc.png \
    --z-arg snr --plot-scatter --plot-marginal \
    --plot-contours --contour-color black \
    --parameters \
        'mass1_from_mchirp_q(mchirp,q)':mass1 \
        'mass2_from_mchirp_q(mchirp,q)':mass2 \
        tc \
    --expected-parameters \
        'mass1_from_mchirp_q(mchirp,q)':1015522.4376 \
        'mass2_from_mchirp_q(mchirp,q)':796849.1091 \
        tc:4799624.274911478 \