pycbc_condition_strain \
    --frame-files /workspace/chendawww/server/data/GW170608/H-H1_GWOSC_16KHZ_R1-1180920447-4096.gwf \
    --channel-name H1:GWOSC-16KHZ_R1_STRAIN \
    --injection-file /workspace/chendawww/server/pe/GW170608/Injection/gr/inject/injection-H1-GW170608.hdf \
    --output-strain-file /workspace/chendawww/server/data/GW170608/H-H1_GWOSC_16KHZ_R1-1180920447-4096_injected.gwf \
    --strain-high-pass 15\
    --pad-data 8 \
    --gps-start-time 1180921470\
    --gps-end-time 1180923518

pycbc_condition_strain \
    --frame-files /workspace/chendawww/server/data/GW170608/L-L1_GWOSC_16KHZ_R1-1180920447-4096.gwf \
    --channel-name L1:GWOSC-16KHZ_R1_STRAIN \
    --injection-file /workspace/chendawww/server/pe/GW170608/Injection/gr/inject/injection-H1-GW170608.hdf \
    --output-strain-file /workspace/chendawww/server/data/GW170608/L-L1_GWOSC_16KHZ_R1-1180920447-4096_injected.gwf \
    --strain-high-pass 15\
    --pad-data 8 \
    --gps-start-time 1180921470\
    --gps-end-time 1180923518