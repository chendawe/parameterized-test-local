#!/bin/sh
pycbc_create_injections --verbose \
        --config-files /workspace/chendawww/server/pe/GW150914_095045/injection/gr/inject/injection_wf_config.ini \
        --ninjections 1 \
        --seed 170608 \
        --output-file /workspace/chendawww/server/pe/GW150914_095045/injection/gr/inject/injection.hdf \
        --variable-params-section variable_params \
        --static-params-section static_params \
        --force