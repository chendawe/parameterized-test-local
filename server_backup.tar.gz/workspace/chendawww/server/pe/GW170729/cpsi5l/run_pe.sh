#!/bin/sh

conda init

conda activate preload

pip show dynesty
conda env list

work_path=/workspace/chendawww/server/pe/GW170729/cpsi5l

cd ${work_path}

# configuration files
CONFIG=/workspace/chendawww/server/pe/GW170729/cpsi5l/inference-GW170729.ini

OUTPUT_PATH=/workspace/chendawww/server/pe/GW170729/cpsi5l/GW170729_cpsi5l.hdf

# the following sets the number of cores to use; adjust as needed to
# your computer's capabilities
NPROCS=64

# run sampler
# Running with OMP_NUM_THREADS=1 stops lalsimulation
# from spawning multiple jobs that would otherwise be used
# by pycbc_inference and cause a reduced runtime.
OMP_NUM_THREADS=1 \
pycbc_inference --verbose \
    --seed 170729 \
    --config-file ${CONFIG} \
    --output-file ${OUTPUT_PATH} \
    --nprocesses ${NPROCS} \
    --force

# --seed 1897234 \