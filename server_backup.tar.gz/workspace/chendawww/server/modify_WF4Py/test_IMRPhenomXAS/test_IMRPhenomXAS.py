from WF4Py import waveforms as WF;
from WF4Py import WFutils as utils;

import numpy as np
from astropy.cosmology import Planck18
from astropy.cosmology import z_at_value
from astropy import units as u

import pycbc.conversions as cvs;
import pycbc.waveform as wf;
import pycbc.types as tps;

import time
import sys
import os

import matplotlib.pyplot as pp
from matplotlib import gridspec
from matplotlib import rc
rc('text', usetex=False)

ourcodenameString = 'WF4Py'

import numpy as np
# 保留原代码的依赖导入（根据你的环境补充）
# import cvs, WF, tps


import lal as _lal


def get_IMRPhenomXAS(**params) :
       params.pop('approximant')
       return wf.get_fd_waveform(approximant='IMRPhenomXAS', **params)

